sudo sh tcpdump_start.sh
python3 2.py
python work_fix.py
